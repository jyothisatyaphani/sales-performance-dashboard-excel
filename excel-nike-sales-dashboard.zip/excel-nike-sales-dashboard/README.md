# Nike-Themed Sales Performance Dashboard (Excel)

A brand-themed sales dashboard built entirely in Excel, modelled on the public segment structure of a global sportswear company (geographies, product categories, channels, brands, fiscal calendar).

> **Disclaimer:** All data is **synthetic** (randomly generated). These are **not** real Nike results. This is an independent portfolio concept, not affiliated with or endorsed by Nike, Inc. No logos are used.

![Dashboard preview](dashboard_preview.png)

## What it shows
- **KPI cards:** Net Revenue, Gross Margin, Units Sold, Average Selling Price, YoY Growth, Revenue vs Target
- **Regional scorecard:** revenue (data bars), YoY (arrow icons), gross margin, vs target (traffic lights), share of total
- **Heatmap:** geography × category revenue (color scale)
- **Charts:** revenue by fiscal month (FY2025 vs FY2026), category mix, channel mix by geography, revenue by brand
- **Filters:** Fiscal Year, Geography and Channel dropdowns

## Workbook structure
| Sheet | Purpose |
|---|---|
| `Dashboard` | KPI cards, scorecard, heatmap, charts, filters |
| `Summary` | `SUMIFS` tables that feed the charts |
| `Data` | 1,728 synthetic monthly rows: geography, category, channel, brand, units, revenue, COGS, target |
| `About` | Notes and definitions |

## Excel skills demonstrated
`SUMIFS` with wildcard "All" filters, fiscal-calendar formulas (`MOD`, `MONTH`, `YEAR`), conditional formatting (data bars, icon sets, color scales), data validation dropdowns, KPI card design, target-vs-actual and YoY analysis, custom number formats ($B / $M).

## Using your own data
Paste your rows into `Data` (same 12 columns; keep the formulas in columns A, C and K) and extend the ranges (`$2:$1729`) if you have more rows.
